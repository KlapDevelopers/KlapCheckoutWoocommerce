<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 */
class KlapCheckoutActivator {

	public static function activate() {
	}
}
